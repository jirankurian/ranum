fn main() {
    println!("Welcome to ranum");
}
